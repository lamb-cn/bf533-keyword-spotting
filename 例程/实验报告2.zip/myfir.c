#include "myfir.h"

void myfir(const fract16 x[], fract16 y[], int n, fir_state_fr16 *s)
{
    int i, j;
    int temp;
    int tapL;
    int M = s->k;

    for (i = 0; i < n; i++)
    {
        tapL = (i + 1 < M) ? (i + 1) : M;
        temp = 0;

        for (j = 0; j < tapL; j++)
            temp += x[i - j] * s->h[j];

        y[i] = (fract16)((temp + 0x3FFF) >> 15);
    }
}
