.section program;
.global __fir_Smac_asm;
.align 8;
__fir_Smac_asm:

    P1 = [SP+12];

    // entre address of struct "s", entre address of array "h"
    I0 = R0;               // I0: Address Index of Input
    I1 = R1;               // I1: Address Index of Output
    P0 = R2;               // P0: number of input samples

    R0 = [P1++];
    B2 = R0;               // base address of array "s.h"

    R0 = [P1++];
    B3 = R0;               // base address of array "s.d"

    R3 = [P1++];           // R3: number of coefficients "s.k"
    P3 = R3;               // P3: number of coefficients

    R3 = R3 + R3;          // coefficient/delay buffer length in bytes

    L2 = R3;               // circular buffer length for coefficients
    I2 = B2;               // coefficient read pointer

    L3 = R3;               // circular buffer length for delay line
    I3 = B3;               // delay-line pointer


/********************************************************************/
// FIR Loop by using single MAC

    LSETUP(FIR_START, FIR_END) LC0 = P0;
FIR_START:
    R0.L = W[I0++];        // get current input sample
    W[I3] = R0.L;          // write current sample into delay line
    A0 = 0;                // clear accumulator for new output
    LSETUP(MAC_START, MAC_END) LC1 = P3;
MAC_START:
    R1.L = W[I2++];        // get h[j]
    R2.L = W[I3--];        // get x[n-j]
MAC_END:
    R3.L = (A0 += R1.L * R2.L);  // single MAC
    W[I1++] = R3.L;        // store output sample
FIR_END:

    I3 += 2;               // move delay-line write pointer to next position
/********************************************************************/
    L2 = 0;                // Clear the circular buffer initialization
    L3 = 0;

    RTS;
__fir_Smac_asm.end: